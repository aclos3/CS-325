Written by Junhyeok Jeong
This is README.txt for explaining how to compile wrestler.py

###if you have wrestler.py file on your ssh directory

1. Make the file be excutable on ssh
chmod +x wrestler.py

2. Before compile wrestler.py, make sure the input files(wrestler.txt, wrestler1.txt, wrestler2.txt, and wrestler4.txt) are existed on your directory

3. As the file is written as python 3, compile with this command on ssh
python3 wrestler.py

4. After compile, enter file name correctly!
ex)
wrester.txt

5. if the file contents are statisfied, then result will be printed on the terminal !

Thank you !
